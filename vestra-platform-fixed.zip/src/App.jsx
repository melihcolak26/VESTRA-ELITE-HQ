import { useState, useCallback, useEffect } from 'react'
import './App.css'
import { DECISION_TEMPLATES } from './templates/data'
import Wizard from './components/Wizard'
import Analyst from './components/Analyst'

function App() {
  const [view, setView] = useState(() => localStorage.getItem('vestra_view') || 'landing')
  const [selectedTemplate, setSelectedTemplate] = useState(null)

  useEffect(() => {
    localStorage.setItem('vestra_view', view)
  }, [view])

  const startWizard = (template) => {
    setSelectedTemplate(template)
    setView('wizard')
  }

  return (
    <div className="platform-root">
      {view === 'landing' && (
        <div className="landing fade-in">
          <header className="hero-section">
            <div className="container">
              <nav className="main-nav">
                <div className="brand">VESTRA <span>Intelligence</span></div>
                <div className="nav-actions">
                  <button className="btn btn-outline" onClick={() => setView('analyst')}>Analyst Mode</button>
                  <button className="btn btn-primary">Sign In</button>
                </div>
              </nav>

              <div className="hero-content">
                <div className="badge-pro mb-3">V5.0 MASTER EDITION</div>
                <h1>Kritik kararları <span>veriyle</span> alın.</h1>
                <p>Orti ve Melih Çolak tarafından geliştirilen Vestra, hibrit MCDM modellerini kullanarak en karmaşık seçimleri bilimsel bir şölene dönüştürür.</p>
                
                <div className="hero-buttons">
                  <button className="btn btn-primary btn-lg" onClick={() => document.getElementById('templates').scrollIntoView({behavior:'smooth'})}>
                    Hızlı Sihirbaz
                  </button>
                  <button className="btn btn-secondary btn-lg" onClick={() => setView('analyst')}>Profesyonel Panel</button>
                </div>
              </div>
            </div>
          </header>

          <section id="templates" className="templates-section">
            <div className="container">
              <div className="section-title">
                <h2>Akıllı Şablonlar</h2>
                <p>Sizin için özelleştirilmiş, en çok kullanılan karar senaryoları.</p>
              </div>

              <div className="template-grid">
                {Object.values(DECISION_TEMPLATES).map(t => (
                  <div key={t.id} className="template-card" onClick={() => startWizard(t)}>
                    <div className="t-icon">{t.icon}</div>
                    <h3>{t.name}</h3>
                    <p>{t.description}</p>
                    <div className="t-badge">Başlat →</div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="features-highlight">
             <div className="container">
               <div className="feat-grid">
                  <div className="feat-item">
                    <h4>12+ Hibrit Model</h4>
                    <p>Entropy, TOPSIS, EDAS ve daha fazlası.</p>
                  </div>
                  <div className="feat-item">
                    <h4>AI Insights</h4>
                    <p>Sonuçları sizin için yorumlayan akıllı sistem.</p>
                  </div>
                  <div className="feat-item">
                    <h4>Persistence</h4>
                    <p>Çalışmalarınız tarayıcıda otomatik saklanır.</p>
                  </div>
               </div>
             </div>
          </section>

          <footer className="main-footer">
            <div className="container">
              <div className="footer-content">
                <p>© 2026 Vestra Decision Technologies.</p>
                <p>Melih Çolak & <strong>Orti</strong> Ortaklığı 🤝</p>
              </div>
            </div>
          </footer>
        </div>
      )}

      {view === 'wizard' && selectedTemplate && (
        <div className="container py-5">
          <Wizard template={selectedTemplate} onBack={() => setView('landing')} />
        </div>
      )}

      {view === 'analyst' && (
        <Analyst onBack={() => setView('landing')} />
      )}
    </div>
  )
}

export default App
