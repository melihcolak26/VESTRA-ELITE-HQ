import React, { useState, useEffect, useMemo } from 'react';
import { 
  topsis, edas, codas, 
  calculateEntropyWeights, 
  calculateCriticWeights,
  calculateAhpWeights 
} from '../engine/mcdm';

const Analyst = ({ onBack }) => {
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('vestra_analyst_data');
    return saved ? JSON.parse(saved) : {
      alternatives: ['Alternatif 1', 'Alternatif 2', 'Alternatif 3'],
      criteria: [
        { name: 'Maliyet', beneficial: false },
        { name: 'Kalite', beneficial: true },
        { name: 'Hız', beneficial: true }
      ],
      matrix: [
        [100, 8, 7],
        [120, 9, 6],
        [90, 7, 9]
      ]
    };
  });

  const [activeWeight, setActiveWeight] = useState('entropy');
  const [activeRank, setActiveRank] = useState('topsis');

  useEffect(() => {
    localStorage.setItem('vestra_analyst_data', JSON.stringify(data));
  }, [data]);

  const weights = useMemo(() => {
    if (activeWeight === 'entropy') return calculateEntropyWeights(data.matrix);
    if (activeWeight === 'critic') return calculateCriticWeights(data.matrix);
    return new Array(data.criteria.length).fill(1 / data.criteria.length);
  }, [data.matrix, activeWeight, data.criteria.length]);

  const results = useMemo(() => {
    const beneficial = data.criteria.map(c => c.beneficial);
    if (activeRank === 'topsis') return topsis(data.matrix, weights, beneficial);
    if (activeRank === 'edas') return edas(data.matrix, weights, beneficial);
    return codas(data.matrix, weights, beneficial);
  }, [data.matrix, weights, data.criteria, activeRank]);

  const updateMatrix = (i, j, val) => {
    const n = [...data.matrix];
    n[i] = [...n[i]];
    n[i][j] = parseFloat(val) || 0;
    setData({ ...data, matrix: n });
  };

  return (
    <div className="analyst-container fade-in">
      <div className="analyst-sidebar">
        <button className="btn btn-secondary mb-4" onClick={onBack}>← Ana Sayfa</button>
        <div className="config-card">
          <h3>Yöntem Seçimi</h3>
          <div className="select-group">
            <label>Ağırlıklandırma</label>
            <select value={activeWeight} onChange={e => setActiveWeight(e.target.value)}>
              <option value="entropy">Entropy (Bilimsel)</option>
              <option value="critic">CRITIC (Korelasyonel)</option>
              <option value="manual">Eşit Dağılım</option>
            </select>
          </div>
          <div className="select-group mt-3">
            <label>Sıralama Modeli</label>
            <select value={activeRank} onChange={e => setActiveRank(e.target.value)}>
              <option value="topsis">TOPSIS (İdeal Çözüm)</option>
              <option value="edas">EDAS (Ortalamadan Uzaklık)</option>
              <option value="codas">CODAS (Karma Mesafe)</option>
            </select>
          </div>
        </div>

        <div className="insights-card mt-4">
          <h3>VESTRA Insights 🧠</h3>
          <p>
            {results.ranking[0].name} seçeneği, {activeRank.toUpperCase()} modeline göre 
            <strong> {results.ranking[0].score.toFixed(3)}</strong> puanla zirvede. 
            Ağırlıklar incelendiğinde en baskın kriter: <strong>{data.criteria[weights.indexOf(Math.max(...weights))].name}</strong>.
          </p>
        </div>
      </div>

      <div className="analyst-main">
        <div className="card">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h2>📊 Karar Matrisi</h2>
            <div className="btn-group">
              <button className="btn btn-secondary btn-sm" onClick={() => {
                const alt = `Alt ${data.alternatives.length + 1}`;
                setData({...data, alternatives: [...data.alternatives, alt], matrix: [...data.matrix, new Array(data.criteria.length).fill(0)]});
              }}>+ Alternatif</button>
              <button className="btn btn-secondary btn-sm" onClick={() => {
                const crit = { name: `Kriter ${data.criteria.length + 1}`, beneficial: true };
                setData({...data, criteria: [...data.criteria, crit], matrix: data.matrix.map(r => [...r, 0])});
              }}>+ Kriter</button>
            </div>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table className="matrix-table analyst-table">
              <thead>
                <tr>
                  <th>Alternatif</th>
                  {data.criteria.map((c, i) => (
                    <th key={i}>
                      <input type="text" className="cell-header" value={c.name} onChange={e => {
                        const n = [...data.criteria]; n[i].name = e.target.value; setData({...data, criteria: n});
                      }} />
                      <div className="beneficial-toggle" onClick={() => {
                         const n = [...data.criteria]; n[i].beneficial = !n[i].beneficial; setData({...data, criteria: n});
                      }}>
                        {c.beneficial ? '↑ Fayda' : '↓ Maliyet'}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.alternatives.map((name, i) => (
                  <tr key={i}>
                    <td className="alt-name-input">
                      <input type="text" value={name} onChange={e => {
                        const n = [...data.alternatives]; n[i] = e.target.value; setData({...data, alternatives: n});
                      }} />
                    </td>
                    {data.criteria.map((_, j) => (
                      <td key={j}>
                        <input type="number" step="any" value={data.matrix[i][j]} onChange={e => updateMatrix(i, j, e.target.value)} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
              </table>
            </div>
          </div>

          <div className="results-grid mt-4">
            <div className="card">
              <h3>🏆 Sonuç Sıralaması</h3>
              <div className="ranking-list">
                {results.ranking.map((res, i) => (
                  <div key={i} className="ranking-item">
                    <div className={`rank ${i === 0 ? 'gold' : ''}`}>{i + 1}</div>
                    <div className="name">{data.alternatives[res.index]}</div>
                    <div className="score">{res.score.toFixed(4)}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="card">
              <h3>⚖️ Kriter Ağırlıkları ({activeWeight.toUpperCase()})</h3>
              <div className="weights-visual">
                {weights.map((w, i) => (
                  <div key={i} className="w-bar-container">
                    <div className="w-label">{data.criteria[i].name}</div>
                    <div className="w-track">
                      <div className="w-fill" style={{ width: `${w * 100}%` }}></div>
                    </div>
                    <div className="w-val">{(w * 100).toFixed(1)}%</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
};

export default Analyst;
