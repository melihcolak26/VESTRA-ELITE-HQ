import React, { useState, useMemo } from 'react';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend, 
  RadialLinearScale, 
  PointElement, 
  LineElement, 
  Filler 
} from 'chart.js';
import { Bar, Radar } from 'react-chartjs-2';
import { 
  LayoutDashboard, 
  Database, 
  Cpu, 
  ChevronLeft, 
  Plus, 
  Zap, 
  FileText, 
  Settings,
  TrendingUp
} from 'lucide-react';
import { topsis, edas, codas, calculateEntropyWeights, calculateCriticWeights } from '../engine/mcdm';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Title,
  Tooltip,
  Legend
);

const Analyst = ({ onBack }) => {
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('vestra_analyst_data');
    return saved ? JSON.parse(saved) : {
      alternatives: ['Tesla Model S', 'BMW i7', 'Lucid Air'],
      criteria: [
        { name: 'Menzil (km)', beneficial: true },
        { name: 'Fiyat ($)', beneficial: false },
        { name: 'Performans (0-100)', beneficial: false },
        { name: 'Otonom Sürüş', beneficial: true }
      ],
      matrix: [
        [650, 95000, 3.1, 9],
        [600, 120000, 4.5, 8],
        [830, 87000, 3.0, 7]
      ]
    };
  });

  const [activeWeight, setActiveWeight] = useState('entropy');
  const [activeRank, setActiveRank] = useState('topsis');

  const weights = useMemo(() => {
    if (activeWeight === 'entropy') return calculateEntropyWeights(data.matrix);
    if (activeWeight === 'critic') return calculateCriticWeights(data.matrix);
    return new Array(data.criteria.length).fill(1 / data.criteria.length);
  }, [data.matrix, activeWeight, data.criteria.length]);

  const results = useMemo(() => {
    const beneficial = data.criteria.map(c => c.beneficial);
    if (activeRank === 'topsis') return topsis(data.matrix, weights, beneficial);
    if (activeRank === 'edas') return edas(data.matrix, weights, beneficial);
    return codas(data.matrix, weights, beneficial);
  }, [data.matrix, weights, data.criteria, activeRank]);

  const updateMatrix = (i, j, val) => {
    const n = [...data.matrix];
    n[i] = [...n[i]];
    n[i][j] = parseFloat(val) || 0;
    setData({ ...data, matrix: n });
  };

  const chartData = {
    labels: data.alternatives,
    datasets: [{
      label: 'Performans Skoru',
      data: results.scores,
      backgroundColor: 'rgba(16, 185, 129, 0.6)',
      borderColor: '#10b981',
      borderWidth: 2,
      borderRadius: 8,
    }]
  };

  const radarData = {
    labels: data.criteria.map(c => c.name),
    datasets: data.alternatives.map((alt, i) => ({
      label: alt,
      data: data.matrix[i],
      fill: true,
      backgroundColor: `rgba(${10 + i * 50}, ${185 - i * 30}, ${255 - i * 20}, 0.2)`,
      borderColor: `rgb(${10 + i * 50}, ${185 - i * 30}, ${255 - i * 20})`,
    }))
  };

  return (
    <div className="app-layout fade-in">
      <aside className="sidebar-v5 glass">
        <div className="logo-container mb-5">
          <Zap size={24} color="#10b981" />
          <span className="logo-accent">VESTRA</span> PRO
        </div>
        
        <nav className="side-nav">
          <div className="nav-group mb-4">
            <p className="text-secondary text-xs uppercase font-bold mb-3">Workspace</p>
            <button className="nav-item active"><LayoutDashboard size={18} /> Dashboard</button>
            <button className="nav-item"><Database size={18} /> Matrix Editor</button>
          </div>

          <div className="nav-group mb-4">
            <p className="text-secondary text-xs uppercase font-bold mb-3">Engine Config</p>
            <div className="config-glass mb-3">
              <label>Weighting Method</label>
              <select value={activeWeight} onChange={e => setActiveWeight(e.target.value)}>
                <option value="entropy">Shannon Entropy</option>
                <option value="critic">CRITIC Method</option>
                <option value="manual">Equal Distribution</option>
              </select>
            </div>
            <div className="config-glass">
              <label>Ranking Algorithm</label>
              <select value={activeRank} onChange={e => setActiveRank(e.target.value)}>
                <option value="topsis">TOPSIS (Euclidean)</option>
                <option value="edas">EDAS (Mean Distance)</option>
                <option value="codas">CODAS (Taxicab)</option>
              </select>
            </div>
          </div>
        </nav>

        <button className="btn-back mt-auto" onClick={onBack}>
          <ChevronLeft size={18} /> Back to Portal
        </button>
      </aside>

      <main className="content-v5">
        <header className="content-header mb-5 d-flex justify-content-between align-items-center">
          <div>
            <h2 className="text-3xl font-black mb-1">Decision Analysis</h2>
            <p className="text-secondary">Scientific precision meet intuitive analytics.</p>
          </div>
          <div className="d-flex gap-3">
            <button className="btn-v5 glass"><FileText size={18} /> Export PDF</button>
            <button className="btn-v5-primary"><Plus size={18} /> Add Scenario</button>
          </div>
        </header>

        <div className="dashboard-grid">
          <div className="glass p-4 rounded-3xl col-span-2">
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h3 className="font-bold d-flex align-items-center gap-2">
                <Database size={18} /> Decision Matrix
              </h3>
              <div className="d-flex gap-2">
                 <button className="btn-sm-glass" onClick={() => setData({...data, alternatives: [...data.alternatives, `Alt ${data.alternatives.length + 1}`], matrix: [...data.matrix, new Array(data.criteria.length).fill(0)]})}>+ Alternative</button>
                 <button className="btn-sm-glass" onClick={() => setData({...data, criteria: [...data.criteria, {name: `Crit ${data.criteria.length + 1}`, beneficial: true}], matrix: data.matrix.map(r => [...r, 0])})}>+ Criterion</button>
              </div>
            </div>
            <div className="table-responsive">
              <table className="premium-table">
                <thead>
                  <tr>
                    <th>Alternative</th>
                    {data.criteria.map((c, i) => (
                      <th key={i}>
                        <div className="d-flex flex-column">
                          <input className="table-header-input" value={c.name} onChange={e => {
                            const n = [...data.criteria]; n[i].name = e.target.value; setData({...data, criteria: n});
                          }} />
                          <span className="badge-type" onClick={() => {
                            const n = [...data.criteria]; n[i].beneficial = !n[i].beneficial; setData({...data, criteria: n});
                          }}>
                            {c.beneficial ? 'Beneficial' : 'Cost'}
                          </span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.alternatives.map((alt, i) => (
                    <tr key={i}>
                      <td className="font-bold">
                        <input className="table-row-input" value={alt} onChange={e => {
                          const n = [...data.alternatives]; n[i] = e.target.value; setData({...data, alternatives: n});
                        }} />
                      </td>
                      {data.criteria.map((_, j) => (
                        <td key={j}>
                          <input 
                            type="number" 
                            className="input-glass" 
                            value={data.matrix[i][j]} 
                            onChange={e => updateMatrix(i, j, e.target.value)} 
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="glass p-4 rounded-3xl">
            <h3 className="font-bold mb-4 d-flex align-items-center gap-2">
              <TrendingUp size={18} /> Performance Ranking
            </h3>
            <div className="ranking-v5">
              {results.ranking.map((res, i) => (
                <div key={i} className={`rank-card-v5 ${i === 0 ? 'winner' : ''}`}>
                  <span className="rank-idx">{i + 1}</span>
                  <div className="rank-info">
                    <p className="rank-name">{data.alternatives[res.index]}</p>
                    <div className="rank-bar-wrap">
                      <div className="rank-bar" style={{ width: `${(res.score / (results.ranking[0].score || 1)) * 100}%` }}></div>
                    </div>
                  </div>
                  <span className="rank-score">{res.score.toFixed(4)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass p-4 rounded-3xl">
            <h3 className="font-bold mb-4">Criteria Weights</h3>
            <div style={{ height: '300px' }}>
              <Bar 
                data={{
                  labels: data.criteria.map(c => c.name),
                  datasets: [{
                    label: 'Weight',
                    data: weights,
                    backgroundColor: '#6366f1'
                  }]
                }} 
                options={{ maintainAspectRatio: false }} 
              />
            </div>
          </div>

          <div className="glass p-4 rounded-3xl col-span-2">
            <h3 className="font-bold mb-4 d-flex align-items-center gap-2">
              <Cpu size={18} /> VESTRA Engine Insights
            </h3>
            <div className="insight-box p-4 rounded-2xl border-l-4 border-emerald-500 bg-emerald-500/10">
              <p className="text-lg">
                Based on <strong>{activeRank.toUpperCase()}</strong> methodology, 
                <span className="text-emerald-400 font-bold"> {data.alternatives[results.ranking[0].index]}</span> is the optimal choice 
                with a dominance score of <strong>{results.ranking[0].score.toFixed(4)}</strong>. 
                The <strong>{data.criteria[weights.indexOf(Math.max(...weights))].name}</strong> criterion played the most 
                significant role in this determination.
              </p>
            </div>
          </div>
        </div>
      </main>

      <style jsx>{`
        .nav-item {
          display: flex;
          align-items: center;
          gap: 12px;
          width: 100%;
          padding: 12px;
          border-radius: 12px;
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          transition: 0.2s;
        }
        .nav-item.active {
          background: rgba(255,255,255,0.05);
          color: white;
        }
        .config-glass {
          background: rgba(255,255,255,0.03);
          border: 1px solid var(--glass-border);
          padding: 12px;
          border-radius: 12px;
        }
        .config-glass label {
          font-size: 0.7rem;
          color: var(--text-secondary);
          display: block;
          margin-bottom: 4px;
        }
        .config-glass select {
          background: transparent;
          color: white;
          border: none;
          width: 100%;
          font-weight: bold;
        }
        .btn-back {
          background: transparent;
          border: 1px solid var(--glass-border);
          color: var(--text-secondary);
          padding: 12px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .table-header-input, .table-row-input {
          background: transparent;
          border: none;
          color: white;
          font-weight: bold;
        }
        .badge-type {
          font-size: 0.6rem;
          background: rgba(16, 185, 129, 0.1);
          color: #10b981;
          padding: 2px 6px;
          border-radius: 4px;
          width: fit-content;
          cursor: pointer;
        }
        .rank-card-v5 {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 12px;
          background: rgba(255,255,255,0.03);
          border-radius: 12px;
          margin-bottom: 8px;
        }
        .rank-card-v5.winner {
          background: linear-gradient(90deg, rgba(16, 185, 129, 0.1), transparent);
          border-left: 3px solid #10b981;
        }
        .rank-idx { font-weight: 900; opacity: 0.3; }
        .rank-info { flex: 1; }
        .rank-bar-wrap { height: 4px; background: rgba(255,255,255,0.05); border-radius: 2px; margin-top: 4px; }
        .rank-bar { height: 100%; background: #10b981; border-radius: 2px; }
        .btn-v5-primary {
           background: #10b981;
           color: white;
           padding: 10px 20px;
           border-radius: 12px;
           font-weight: bold;
           border: none;
           display: flex;
           align-items: center;
           gap: 8px;
        }
        .btn-sm-glass {
           background: rgba(255,255,255,0.05);
           border: 1px solid var(--glass-border);
           color: white;
           font-size: 0.75rem;
           padding: 4px 12px;
           border-radius: 8px;
        }
      `}</style>
    </div>
  );
};

export default Analyst;
