import { useState, useEffect } from 'react'
import './App.css'
import { DECISION_TEMPLATES } from './templates/data'
import Wizard from './components/Wizard'
import Analyst from './components/Analyst'
import { Zap, Shield, Cpu, BarChart3, ChevronRight, Play } from 'lucide-react'

function App() {
  const [view, setView] = useState(() => localStorage.getItem('vestra_view') || 'landing')
  const [selectedTemplate, setSelectedTemplate] = useState(null)

  useEffect(() => {
    localStorage.setItem('vestra_view', view)
  }, [view])

  const startWizard = (template) => {
    setSelectedTemplate(template)
    setView('wizard')
  }

  return (
    <div className="platform-root">
      {view === 'landing' && (
        <div className="landing-v5">
          <div className="glow-orb" style={{ top: '10%', left: '20%', width: '400px', height: '400px', background: 'rgba(16, 185, 129, 0.15)' }}></div>
          <div className="glow-orb" style={{ bottom: '10%', right: '10%', width: '500px', height: '500px', background: 'rgba(99, 102, 241, 0.1)' }}></div>

          <nav className="nav-premium">
            <div className="logo-container">
              <Zap size={28} color="#10b981" fill="#10b981" />
              <span className="logo-accent">VESTRA</span>
            </div>
            <div className="d-flex gap-4">
              <button className="text-secondary font-bold" onClick={() => setView('analyst')}>Documentation</button>
              <button className="btn-premium" onClick={() => setView('analyst')}>
                Launch Analyst <ChevronRight size={18} />
              </button>
            </div>
          </nav>

          <section className="hero-v5">
            <div className="container">
              <div className="badge-v5 success mb-4">V5.0 Master Intelligence Edition</div>
              <h1 className="gradient-text">Kritik Kararlar,<br/>Bilimsel Sonuçlar.</h1>
              <p className="hero-p mb-5">
                Melih Çolak & Orti tarafından geliştirilen Vestra, karmaşık veri setlerini 
                <strong> 12+ hibrit MCDM modeli</strong> ile işleyerek en doğru stratejiyi belirler.
              </p>
              
              <div className="hero-cta d-flex justify-content-center gap-4">
                <button className="btn-premium-lg" onClick={() => document.getElementById('engine').scrollIntoView({behavior:'smooth'})}>
                   Start Engine <Play size={18} fill="currentColor" />
                </button>
                <button className="btn-glass-lg" onClick={() => setView('analyst')}>
                  Analyst Panel <BarChart3 size={18} />
                </button>
              </div>
            </div>
          </section>

          <section id="engine" className="engine-showcase py-20">
            <div className="container">
              <div className="grid grid-cols-3 gap-8">
                <div className="glass p-8 rounded-3xl text-left">
                  <div className="icon-box mb-4"><Shield color="#10b981" /></div>
                  <h3 className="text-xl font-bold mb-2">Multi-Model Hybrid</h3>
                  <p className="text-secondary">TOPSIS, EDAS ve CODAS modellerinin konsensüsü ile hatasız sonuçlar.</p>
                </div>
                <div className="glass p-8 rounded-3xl text-left">
                  <div className="icon-box mb-4"><Cpu color="#6366f1" /></div>
                  <h3 className="text-xl font-bold mb-2">Automated Weighting</h3>
                  <p className="text-secondary">Shannon Entropy ve CRITIC algoritmaları ile tarafsız kriter ağırlıklandırma.</p>
                </div>
                <div className="glass p-8 rounded-3xl text-left">
                  <div className="icon-box mb-4"><BarChart3 color="#f59e0b" /></div>
                  <h3 className="text-xl font-bold mb-2">Real-time Visuals</h3>
                  <p className="text-secondary">Karar süreçlerinizi dinamik grafikler ve AI Insights ile görselleştirin.</p>
                </div>
              </div>

              <div className="template-grid-v5 mt-20">
                <h2 className="text-4xl font-black mb-10 text-center">Smart Scenarios</h2>
                <div className="grid grid-cols-4 gap-6">
                  {Object.values(DECISION_TEMPLATES).map(t => (
                    <div key={t.id} className="glass p-6 rounded-2xl cursor-pointer hover-scale" onClick={() => startWizard(t)}>
                      <div className="text-4xl mb-4">{t.icon}</div>
                      <h4 className="font-bold mb-2">{t.name}</h4>
                      <p className="text-sm text-secondary mb-4">{t.description}</p>
                      <div className="text-xs font-bold text-emerald-400">Launch Wizard →</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <footer className="py-20 border-t border-white/5">
            <div className="container text-center">
              <p className="text-secondary mb-2">© 2026 Vestra Decision Technologies.</p>
              <p className="font-bold">Melih Çolak & <span className="logo-accent">Orti</span> Intelligence 🤝</p>
            </div>
          </footer>
        </div>
      )}

      {view === 'wizard' && selectedTemplate && (
        <div className="wizard-overlay">
          <Wizard template={selectedTemplate} onBack={() => setView('landing')} />
        </div>
      )}

      {view === 'analyst' && (
        <Analyst onBack={() => setView('landing')} />
      )}

      <style jsx>{`
        .hero-p { font-size: 1.4rem; color: #94a3b8; max-width: 800px; margin: 0 auto 3rem; line-height: 1.6; }
        .btn-premium-lg {
          background: #fff;
          color: #000;
          padding: 1.25rem 3rem;
          border-radius: 100px;
          font-weight: 800;
          font-size: 1.1rem;
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 12px;
          transition: 0.3s;
        }
        .btn-glass-lg {
          background: rgba(255,255,255,0.05);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255,255,255,0.1);
          color: #fff;
          padding: 1.25rem 3rem;
          border-radius: 100px;
          font-weight: 800;
          font-size: 1.1rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 12px;
          transition: 0.3s;
        }
        .btn-premium-lg:hover { transform: scale(1.05); box-shadow: 0 0 30px rgba(255,255,255,0.2); }
        .btn-glass-lg:hover { background: rgba(255,255,255,0.1); }
        .grid { display: grid; }
        .grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
        .grid-cols-4 { grid-template-columns: repeat(4, 1fr); }
        .gap-8 { gap: 2rem; }
        .gap-6 { gap: 1.5rem; }
        .py-20 { padding: 5rem 0; }
        .icon-box { width: 48px; height: 48px; background: rgba(255,255,255,0.05); border-radius: 12px; display: flex; align-items: center; justify-content: center; }
        .hover-scale:hover { transform: translateY(-10px); border-color: var(--primary); }
      `}</style>
    </div>
  )
}

export default App
